# Purview DLP SIT Test Data - Revalidated

This revision contains 27 test cases with 150 rows per case in CSV, DOCX, PPTX, XLSX, TXT, PDF, PNG, and JPEG formats.

Every row contains:

- a globally unique synthetic full name;
- a globally unique synthetic physical address;
- a pattern/checksum-valid identifier;
- an explicit SIT keyword placed next to the identifier;
- supporting evidence used by Microsoft Purview confidence rules where the built-in definition requires it.

## Credit cards

All 150 card numbers were curated from `artisttej/M365/dummy_credit_card_data.csv`, then independently filtered for a recognized Visa, Mastercard, American Express, Discover, Diners Club, or JCB format and a valid Luhn checksum. Every row also carries the detected brand, a future expiration date, a CVV, and the phrase `Credit Card Number`.

## Built-in coverage

24 cases map to current Microsoft built-in SIT definitions. Three requested cases are not listed in the current built-in catalogue and therefore require a custom SIT:

- US Adoption Taxpayer ID Numbers
- US Preparer Taxpayer ID Numbers
- UK Bank Sort Code and Account Number Combinations

Do not interpret local validation as a guarantee of a particular tenant result. Purview detection also depends on policy scope, configured confidence, exclusions, inspection support for the file type, service updates, and proximity rules. Use `SIT_COVERAGE_MATRIX.csv` and `SIT_VALIDATION_REPORT.json` as the acceptance checklist.

All values are fictional synthetic test data. Do not use them for real transactions, identity claims, tax filings, healthcare, banking, or authentication.

## U.S. passport numbers

The U.S. passport dataset contains 150 unique nine-digit values. Every record places the keywords `Passport Number`, `Date of issue`, and `Date of expiry` within the same record to target the built-in U.S./U.K. passport number SIT at high confidence.

## PDF and image formats

Each test case includes one searchable multi-page PDF and one high-resolution PNG and JPEG image. Every image is 2000 x 18888 pixels and contains all 150 records with the identifier, full name, physical address, SIT keyword, and supporting evidence rendered as readable text for OCR testing.
